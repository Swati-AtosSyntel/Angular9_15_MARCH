import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data',
  // template: `<h3>{{name}}
  // </h3>`,
  templateUrl:'./basic.component.html',
  styleUrls: ['./basic.component.css']
})
export class BasicComponent implements OnInit {

  name="Swati";
 
  constructor() { }

  ngOnInit(): void {
  }

}
