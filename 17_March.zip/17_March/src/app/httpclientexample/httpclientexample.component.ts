import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { User } from './User';
@Component({
  selector: 'app-httpclientexample',
  templateUrl: './httpclientexample.component.html',
  styleUrls: ['./httpclientexample.component.css']
})
export class HttpclientexampleComponent implements OnInit {

  users:User[]=[];
  constructor(public http:HttpClient) { }

  ngOnInit(): void {
    this.getUsers();
  }
  getUsers(){
    return this.http.get<User[]>("https://jsonplaceholder.typicode.com/users")
    .subscribe(
      (response)=>{
        console.log('response received');
        console.log(response);
        this.users=response;
      },
      (err)=>{
        console.error('Request failed');
        console.log(err);
      },
      ()=>{
        console.log("Request Completed Successfully");
      }
    )
  };

}
