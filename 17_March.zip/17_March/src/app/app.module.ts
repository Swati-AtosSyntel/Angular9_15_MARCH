import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { BasicComponent } from './basic/basic.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { GenderPipe } from './gender.pipe';
import { HttpclientexampleComponent } from './httpclientexample/httpclientexample.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';

@NgModule({
  declarations: [
    AppComponent,
    BasicComponent,
    EmployeeListComponent,
    GenderPipe,
    HttpclientexampleComponent,
    ParentComponent,
    ChildComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent,BasicComponent]
})
export class AppModule { }
