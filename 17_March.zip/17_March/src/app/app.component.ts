import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Welcome to Angular Application';
  firstName='Anish';
  lastName="Joshi";
  fullName="";
  show=true;
  month=1;
  colors=["Green","Blue","Red","Violet"];
  isSelected=true;
  getFullName(){
    this.fullName=this.firstName+" "+this.lastName;
  }


}
