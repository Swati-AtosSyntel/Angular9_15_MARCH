export interface IEmployee{
    id:number;
    name:string;
    city:string;
    age:number;
    gender:number;
    dob:Date;
    pan:string;
    mobile:string;
    salary:number;
}