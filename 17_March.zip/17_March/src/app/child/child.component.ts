import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Input()
numReceived:number=0;
@Output()
thanks=new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  sayThanks(){
    this.thanks.emit("Thank you for sharing updated number as "+this.numReceived+"!!!");

  }

}
