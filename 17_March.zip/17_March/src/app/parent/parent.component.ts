import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  thanksMessage="";
num=0;
SendToChild(){
  this.num++;
  console.log(this.num);
}
  constructor() { }

  ngOnInit(): void {
  }
receiveThanks(event:any){
  this.thanksMessage=event;
  console.log(this.thanksMessage);
}
}
